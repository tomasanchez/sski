# Simulacro de parcial FMS
Enunciado: https://docs.google.com/document/d/1AtD9mZGiUNEKmZ_aaWSCoNaeowLTMUhFRVHm-GZIF-w/edit?usp=sharing
