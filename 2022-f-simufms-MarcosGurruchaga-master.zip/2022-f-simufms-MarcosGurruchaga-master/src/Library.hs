module Library where
import PdePreludat

doble :: Number -> Number
doble numero = numero + numero

type Palabra = String
type Verso = String
type Estrofa = [Verso]
type Artista = String -- Solamente interesa el nombre
 
esVocal :: Char -> Bool
esVocal = flip elem "aeiouáéíóú"
 
tieneTilde :: Char -> Bool
tieneTilde = flip elem "áéíóú"
 
cumplen :: (a -> b) -> (b -> b -> Bool) -> a -> a -> Bool
cumplen f comp v1 v2 = comp (f v1) (f v2)

soloVocales = filter (esVocal) 

ultimasDosLetras :: Palabra -> Palabra
ultimasDosLetras [x1,x2] = [x1,x2]
ultimasDosLetras [x1] = [x1]
ultimasDosLetras [] = []
ultimasDosLetras (x:xs) = ultimasDosLetras xs

ultimasTresLetras :: Palabra -> Palabra
ultimasTresLetras [x1,x2,x3] = [x1,x2,x3]
ultimasTresLetras [x1,x2] = [x1,x2]
ultimasTresLetras [x1] = [x1]
ultimasTresLetras [] = []
ultimasTresLetras (x:xs) = ultimasTresLetras xs

rima :: Palabra -> Palabra -> Bool
rima p1 p2 
    | (p1 == p2) = False 
    | ultimasTresLetras p1 == ultimasTresLetras p2 = True
    | ultimasDosLetras (soloVocales p1) == ultimasDosLetras (soloVocales p2) = True
    | otherwise=False

ultimaPalabra = last.words
primerPalabra = head.words

porRimas :: Verso -> Verso -> Bool
porRimas ver1 ver2 = rima (ultimaPalabra ver1) (ultimaPalabra ver2) 

porAnadi :: Verso -> Verso -> Bool
porAnadi ver1 ver2 = rima (primerPalabra ver2) (ultimaPalabra ver1) 

todasconju :: Verso -> Verso -> Bool
todasconju ver1 ver2 = porRimas ver1 ver2 || porAnadi ver1 ver2
type Conjugaciones = Verso -> Verso -> Bool

estrofita = ["mi padre murio de fuchibol", "porque era estupido" ,"pero aguante el futbol"]
estrofita2 = ["mi padre murio de fuchibolix", "porque era estupido" ,"pero aguante el futbol"]

estrofaestrujula = ["a ponerse los guantes y subir al cuadrilátero","que después de este parcial acerca el paradigma lógico","no entiendo por qué está fallando mi código","si todas estas frases terminan en esdrújulas"]
patronSimple :: Estrofa -> Bool
patronSimple [x] = False
patronSimple (x:xs) = any (rima (ultimaPalabra x)) (map (ultimaPalabra) xs) || patronSimple xs 

patronEsdrujulas :: Estrofa -> Bool
patronEsdrujulas = all(esEsdrujula) 

esEsdrujula = tieneTilde.head.ultimasTresLetras.soloVocales.ultimaPalabra

